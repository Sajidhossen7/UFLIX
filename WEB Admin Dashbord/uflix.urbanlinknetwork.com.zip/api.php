<?php
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "urbanlin_sajid_user", "FaA3h8UPpuCH7tu", "urbanlin_uflix_db");

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection Failed"]));
}

// সার্ভার লিস্ট তুলে আনা
$result = $conn->query("SELECT server_name, server_url FROM uflix_servers");
$servers = [];
while($row = $result->fetch_assoc()) {
    $servers[] = [
        "name" => $row['server_name'],
        "url" => $row['server_url']
    ];
}

// নোটিশ তুলে আনা
$notice_query = $conn->query("SELECT setting_value FROM uflix_settings WHERE setting_key = 'app_notice'");
$app_notice = "Welcome to UFLIX! Enjoy the best servers."; // ডিফল্ট
if ($notice_query->num_rows > 0) {
    $app_notice = $notice_query->fetch_assoc()['setting_value'];
}

if (count($servers) > 0) {
    // এখন রেসপন্সে servers-এর পাশাপাশি notice-ও পাঠানো হচ্ছে
    echo json_encode(["status" => "success", "servers" => $servers, "notice" => $app_notice]);
} else {
    echo json_encode(["status" => "error", "message" => "No servers found"]);
}

$conn->close();
?>