<?php
session_start();

// সিকিউরিটি চেক
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

// লগআউট লজিক
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// ডাটাবেস কানেকশন
$conn = new mysqli("localhost", "urbanlin_sajid_user", "FaA3h8UPpuCH7tu", "urbanlin_uflix_db");

// নোটিশ আপডেট করার লজিক
if (isset($_POST['update_notice'])) {
    $notice = $conn->real_escape_string($_POST['notice_text']);
    $conn->query("UPDATE uflix_settings SET setting_value = '$notice' WHERE setting_key = 'app_notice'");
    header("Location: dashboard.php");
    exit;
}

// সার্ভার অ্যাড করার লজিক
if (isset($_POST['add_server'])) {
    $name = $conn->real_escape_string($_POST['server_name']);
    $url = $conn->real_escape_string($_POST['server_url']);
    $conn->query("INSERT INTO uflix_servers (server_name, server_url) VALUES ('$name', '$url')");
    header("Location: dashboard.php");
    exit;
}

// সার্ভার আপডেট (Edit) করার লজিক
if (isset($_POST['update_server'])) {
    $id = (int)$_POST['server_id'];
    $name = $conn->real_escape_string($_POST['server_name']);
    $url = $conn->real_escape_string($_POST['server_url']);
    $conn->query("UPDATE uflix_servers SET server_name='$name', server_url='$url' WHERE id=$id");
    header("Location: dashboard.php");
    exit;
}

// সার্ভার ডিলিট করার লজিক
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM uflix_servers WHERE id = $id");
    header("Location: dashboard.php");
    exit;
}

// এডিট করার জন্য নির্দিষ্ট সার্ভারের ডাটা তুলে আনা
$edit_mode = false;
$edit_server = [];
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id = (int)$_GET['edit'];
    $result = $conn->query("SELECT * FROM uflix_servers WHERE id = $id");
    if ($result->num_rows > 0) {
        $edit_server = $result->fetch_assoc();
    }
}

// বর্তমান নোটিশ তুলে আনা
$notice_query = $conn->query("SELECT setting_value FROM uflix_settings WHERE setting_key = 'app_notice'");
$current_notice = $notice_query->fetch_assoc()['setting_value'] ?? "No notice found";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UFLIX - Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background-color: #0f172a; color: #e2e8f0; font-family: 'Segoe UI', sans-serif; }
        .fade-in-up { animation: fadeInUp 0.8s cubic-bezier(0.165, 0.84, 0.44, 1) forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .glass-card { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.05); }
        .input-dark { background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); color: white; }
        .input-dark:focus { border-color: #E50914; outline: none; box-shadow: 0 0 10px rgba(229, 9, 20, 0.3); }
    </style>
</head>
<body class="min-h-screen p-6">

    <nav class="flex justify-between items-center mb-10 fade-in-up">
        <div>
            <h1 class="text-4xl font-extrabold text-[#E50914] tracking-wider">UFLIX<span class="text-white text-lg ml-2 font-normal opacity-70">Admin Panel</span></h1>
        </div>
        <div>
            <a href="?logout=true" class="bg-red-600 hover:bg-red-700 text-white px-5 py-2 rounded-lg font-semibold transition duration-300 shadow-lg shadow-red-500/30">Log Out</a>
        </div>
    </nav>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">

        <div class="md:col-span-1 fade-in-up delay-100 space-y-6">
            
            <div class="glass-card p-6 rounded-2xl shadow-2xl">
                <h3 class="text-xl font-bold mb-4 border-b border-gray-700 pb-2 text-gray-200">📢 App Notice</h3>
                <form method="POST" class="space-y-4">
                    <div>
                        <textarea name="notice_text" rows="3" required class="input-dark w-full px-4 py-3 rounded-lg transition duration-300"><?php echo htmlspecialchars($current_notice); ?></textarea>
                    </div>
                    <button type="submit" name="update_notice" class="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 px-4 rounded-lg transition duration-300 shadow-lg mt-2">
                        Update Notice
                    </button>
                </form>
            </div>

            <div class="glass-card p-6 rounded-2xl shadow-2xl transform transition hover:-translate-y-1 duration-300">
                <h3 class="text-xl font-bold mb-4 border-b border-gray-700 pb-2 text-gray-200">
                    <?php echo $edit_mode ? '✏️ Edit Server' : '➕ Add New Server'; ?>
                </h3>
                <form method="POST" class="space-y-4">
                    <?php if($edit_mode): ?>
                        <input type="hidden" name="server_id" value="<?php echo $edit_server['id']; ?>">
                    <?php endif; ?>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-400 mb-1">Server Name</label>
                        <input type="text" name="server_name" value="<?php echo $edit_mode ? htmlspecialchars($edit_server['server_name']) : ''; ?>" placeholder="e.g., BDIX VIP" required class="input-dark w-full px-4 py-3 rounded-lg transition duration-300">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-400 mb-1">Stream URL (FTP/HTTP)</label>
                        <input type="url" name="server_url" value="<?php echo $edit_mode ? htmlspecialchars($edit_server['server_url']) : ''; ?>" placeholder="http://..." required class="input-dark w-full px-4 py-3 rounded-lg transition duration-300">
                    </div>
                    
                    <?php if($edit_mode): ?>
                        <div class="flex gap-2 mt-2">
                            <button type="submit" name="update_server" class="flex-1 bg-yellow-600 hover:bg-yellow-500 text-white font-bold py-3 rounded-lg transition duration-300">Update</button>
                            <a href="dashboard.php" class="flex-1 bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 rounded-lg transition duration-300 text-center">Cancel</a>
                        </div>
                    <?php else: ?>
                        <button type="submit" name="add_server" class="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 px-4 rounded-lg transition duration-300 shadow-lg mt-2">Add to Network</button>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="md:col-span-2 fade-in-up delay-200">
            <div class="glass-card p-6 rounded-2xl shadow-2xl">
                <h3 class="text-xl font-bold mb-5 border-b border-gray-700 pb-2 text-gray-200">🌐 Active Servers</h3>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-800 text-gray-300 text-sm uppercase tracking-wide">
                                <th class="p-4 rounded-tl-lg">ID</th>
                                <th class="p-4">Server Name</th>
                                <th class="p-4">URL</th>
                                <th class="p-4 rounded-tr-lg text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-400 text-sm">
                            <?php
                            $result = $conn->query("SELECT * FROM uflix_servers");
                            if($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr class='border-b border-gray-700/50 hover:bg-slate-800/50 transition duration-200'>
                                            <td class='p-4 font-mono'>{$row['id']}</td>
                                            <td class='p-4 font-semibold text-gray-200'>{$row['server_name']}</td>
                                            <td class='p-4 truncate max-w-xs'>{$row['server_url']}</td>
                                            <td class='p-4 text-center'>
                                                <a href='?edit={$row['id']}' class='text-yellow-500 hover:text-yellow-400 bg-yellow-500/10 hover:bg-yellow-500/20 px-3 py-1 rounded transition duration-200 mr-2'>Edit</a>
                                                <a href='?delete={$row['id']}' onclick=\"return confirm('Are you sure you want to delete this server?');\" class='text-red-500 hover:text-red-400 bg-red-500/10 hover:bg-red-500/20 px-3 py-1 rounded transition duration-200'>Delete</a>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4' class='p-6 text-center text-gray-500 italic'>No active servers found. Add one from the left panel.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</body>
</html>