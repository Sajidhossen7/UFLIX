<?php
session_start();

// যদি আগে থেকেই লগইন করা থাকে, তবে সরাসরি ড্যাশবোর্ডে নিয়ে যাবে
if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = "";

// লগইন সাবমিট হলে চেক করবে
if(isset($_POST['login'])) {
    $admin_user = "admin";
    $admin_pass = "Uflix@2026"; // তোমার সিকিউর পাসওয়ার্ড

    if($_POST['username'] === $admin_user && $_POST['password'] === $admin_pass) {
        $_SESSION['logged_in'] = true;
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Incorrect Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UFLIX - Secure Network Access</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #0f172a; 
            margin: 0;
            overflow: hidden;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: 1;
        }
        
        .login-container {
            position: relative;
            z-index: 10;
        }
        
        .glass-panel {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        
        .input-field {
            background: rgba(0, 0, 0, 0.4);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        .input-field:focus {
            border-color: #E50914;
            box-shadow: 0 0 15px rgba(229, 9, 20, 0.4);
            outline: none;
        }
        
        .uflix-logo {
            text-shadow: 0 0 20px rgba(229, 9, 20, 0.8);
        }
    </style>
</head>
<body class="h-screen flex items-center justify-center">

    <div id="particles-js"></div>

    <div class="login-container glass-panel p-10 rounded-2xl w-96 transform transition-all hover:scale-105 duration-500">
        
        <div class="text-center mb-8">
            <h1 class="text-5xl font-extrabold text-[#E50914] tracking-widest uflix-logo">UFLIX</h1>
            <p class="text-gray-400 mt-2 text-sm font-semibold tracking-wide">NETWORK ADMIN GATEWAY</p>
        </div>

        <?php if($error != ""): ?>
            <div class="bg-red-500/20 border border-red-500 text-red-400 px-4 py-3 rounded mb-4 text-center text-sm font-semibold animate-pulse">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-5">
                <label class="block text-gray-400 text-xs font-bold mb-2 uppercase tracking-wide">Username</label>
                <input type="text" name="username" class="input-field w-full py-3 px-4 rounded-lg" placeholder="Enter admin username" required autocomplete="off">
            </div>
            
            <div class="mb-8 relative">
                <label class="block text-gray-400 text-xs font-bold mb-2 uppercase tracking-wide">Password</label>
                <div class="relative">
                    <input type="password" id="passwordField" name="password" class="input-field w-full py-3 pl-4 pr-12 rounded-lg" placeholder="Enter secure password" required>
                    
                    <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 flex items-center px-4 text-gray-400 hover:text-[#E50914] focus:outline-none transition-colors">
                        <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                    </button>
                </div>
            </div>
            
            <button type="submit" name="login" class="w-full bg-[#E50914] hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-[0_0_15px_rgba(229,9,20,0.6)]">
                AUTHORIZE ACCESS
            </button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        // Eye Button Toggle Logic
        const togglePassword = document.getElementById('togglePassword');
        const passwordField = document.getElementById('passwordField');
        const eyeIcon = document.getElementById('eyeIcon');

        togglePassword.addEventListener('click', function (e) {
            // Toggle the type attribute
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            
            // Toggle the SVG icon
            if (type === 'text') {
                // Eye Slash Icon
                eyeIcon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />`;
            } else {
                // Eye Open Icon
                eyeIcon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />`;
            }
        });

        // Particles Background Config
        particlesJS("particles-js", {
            "particles": {
                "number": { "value": 70, "density": { "enable": true, "value_area": 800 } },
                "color": { "value": ["#E50914", "#ffffff"] }, 
                "shape": { "type": "circle" },
                "opacity": { "value": 0.5, "random": false },
                "size": { "value": 3, "random": true },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#ffffff",
                    "opacity": 0.2,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 2,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": { "enable": true, "mode": "grab" },
                    "onclick": { "enable": true, "mode": "push" }, 
                    "resize": true
                },
                "modes": {
                    "grab": { "distance": 160, "line_linked": { "opacity": 0.8 } },
                    "push": { "particles_nb": 3 }
                }
            },
            "retina_detect": true
        });
    </script>
</body>
</html>